<?php
namespace Drupal\qr_block\Controller;

class WelcomeController {
  public function welcome() {
    return array(
        '#markup' => 'Welcome to our Website.'
    );
  }
}
