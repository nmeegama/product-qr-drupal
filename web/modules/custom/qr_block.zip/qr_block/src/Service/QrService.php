<?php

namespace Drupal\qr_block\Service;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelLow;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Label\Label;
use Endroid\QrCode\Logo\Logo;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;
/**
 * The DoStuff service. Does a bunch of stuff.
 */
class QrService
{

  /**
   * Does something.
   *
   * @return string
   *   Some value.
   */
  public function generateQrCode($purchase_link)
  {
    $writer = new PngWriter();
    // Create QR code
    $qrCode = QrCode::create($purchase_link)
      ->setEncoding(new Encoding('UTF-8'))
      ->setErrorCorrectionLevel(new ErrorCorrectionLevelLow())
      ->setSize(300)
      ->setMargin(10)
      ->setRoundBlockSizeMode(new RoundBlockSizeModeMargin())
      ->setForegroundColor(new Color(0, 0, 0))
      ->setBackgroundColor(new Color(255, 255, 255));

    $result = $writer->write($qrCode);
    // Directly output the QR code
    header('Content-Type: '.$result->getMimeType());

    // Save it to a file
    //$result->saveToFile(__DIR__.'/qrcode.png');

    // Generate a data URI to include image data inline (i.e. inside an  tag)
    //$dataUri = $result->getDataUri();

    $module_handler = \Drupal::service('module_handler');
    $module_path = $module_handler->getModule('qr_block')->getPath();

    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node instanceof \Drupal\node\NodeInterface) {
      // You can get nid and anything else you need from the node object.
      $nid = $node->id();
    }
    // Save it to a file
    /*
     * TODO : Better to save images in a separate DB table becuase this will generate image every time ,
     * Had to move to this solution because of an issue showing base64 image src
     *
     */
    $result->saveToFile($module_path.'/img/qrcode'.$nid.'.png');
    $dataUri = '/'.$module_path.'/img/qrcode'.$nid.'.png';

    return $dataUri;
  }
}
